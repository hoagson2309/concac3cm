#include <stdio.h>      // for printf
#include "functions.h"  // for read_int

int main(void) {
    return 0;
}
