#include <stdio.h>      // for printf
#include "functions.h"  // for read_int

int main(void) {
    int number1 = read_int();
    int number2 = read_int();
    int number3 = read_int();
    int number4 = read_int();
    int number5 = read_int();
    int number6 = read_int();
    int number7 = read_int();
    int number8 = read_int();
    int number9 = read_int();
    int number10 = read_int();
    printf("You entered the numbers %d, %d, %d, %d, %d, %d, %d, %d, %d, and %d\n", number1, number2, number3, number4, number5, number6, number7, number8, number9, number10);
    return 0;
}
