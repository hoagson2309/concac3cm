#include <stdio.h>
#include "functions.h"

int main(void) {
    return 0;
}
