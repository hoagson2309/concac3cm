#include <stdio.h>
#include "game.h"

int main(void) {

}
