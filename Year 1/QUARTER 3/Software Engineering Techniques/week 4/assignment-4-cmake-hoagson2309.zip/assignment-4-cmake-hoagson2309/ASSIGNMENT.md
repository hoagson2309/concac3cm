# Assignment

Your assignment is to write a *CMakeLists.txt* file that will build the *lift simulation* application. You'll also have to clean-up the directory structure a bit. 

You can see the application running by doing the following (either using `g++` or `clang++`)

```shell
clang++ -std=c++20 *.cpp -o lift_sim.a
./lift_sim.a
```

Or on a Windows machine:

```shell
clang++ -std=c++20 *.cpp -o lift_sim.exe
lift_sim.exe
```

And running the created executable.

Command-line compilation with `msvc` is bit more involved.

## Things to do

**You must commit your changes with a descriptive message after each numbered point/ step. If you forget to do it, you'll loose points.**


1. Structure your project so that there are two extra folders in it:

    * *src*, all the *\*.cpp* files besides *main.cpp* must be placed in it

    * *inc* or *include*, all the header files must be placed in it

    * *main.cpp* should stay in the project's directory.

    > You'll have to pass the compiler option `-Iinc` or `-Iinclude` to make the compiler find the header files if you want to compile from the command line at this stage.

2. Add *CMakeLists.txt* to your main project's folder. Then set-up the basics in it:

    * Define the minimum *CMake* version required for this project.

    * Define the project's name and its version.

    * Add an executable target named `lift_sim`.

    * Add sources (*.cpp* files) to the `lift_sim` target using a separate *CMake* command.

    * Instruct the compiler where to look for headers with `target_include_directories` function.

    * The `lift_sim` target should be able to compile and run after this step.

3. Require a specific language standard

    * Add function calls that will set the required languages standard to at least C++20 for your target.

    * Disable compiler-specific language extensions.

    * The `lift_sim` target should be able to compile and run after this step.

4. Detect the compiler, if it's `GNU`, `Clang` or `AppleClang` set a variable `GNU_COMPATIBLE` to `TRUE`, otherwise set it to `FALSE`. 
   
    If the detected compiler is `GNU_COMPATIBLE` detect the *build type* and:

    * If the *build type* is defined but it is neither *Debug* nor *Release* stop processing and signal a `FATAL_ERROR`.
  
    * If there is no *build type* defined (the variable is an empty string), set the *build type* to `Debug`.

    * The `lift_sim` target should be able to compile and run after this step.

5. If the detected compiler is `GNU_COMPATIBLE`, then using a simple `if()` statement (no *generator expressions*):
    
    * Enable maximum warning level possible and *pedantic* mode for all *build types*.

    * Enable maximum optimizations for the *Release* *build type*.

    * Enable debug optimizations and debug symbol generations for the *Debug* *build type*.

    * The `lift_sim` target should be able to compile and run after this step.

6. If the detected compiler is `MSVC`, then using ***generator expressions***:

    * Enable maximum warning level possible for all *configurations*.

    * Enable maximum optimizations for the *Release* *configurations*.

    * Enable debug optimizations and debug symbol generations for the *Debug* *configuration*.

    * The `lift_sim` target should be able to compile and run after this step.


7. Both the main program and the lift simulator code belong to the same target. That's not such a great idea. You'll now fix this and make a `lib_lift_sim` library. 

    * Change the directory structure by creating a new folder *lib_lift_sim* and moving the *src* and *inc* folders to it. **This will break the compilation because of wrong paths.**

    * Create a new `STATIC` library target named `lib_lift_sim` in the *CMakeLists.txt*. Add all the files from the *src* folder to it. You'll also need to remove those files from the `lift_sim` target.

    * Add the *inc* folder to the `lib_lift_sim` target's include directories in the *CMakeLists.txt* using the appropriate CMake function. Make sure that you do it with the correct visibility (`PRIVATE`, `INTERFACE` or `PUBLIC`) so those include directories are also visible to targets that use `lib_lift_sim`. You'll also need to remove the *inc* folder from the `lift_sim` target's include directories.

    * Enable warnings and optimizations for the `lib_lift_sim` target, similarly as you did for the `lift_sim` target. You don't need to perform elaborate compiler or build type detection. However you must support `clang`, `gnu` and `msvc` compilers. Use *generator expressions* for all compilers.
    
    * Add the `lib_lift_sim` target as a dependency to the `lift_sim` target (`target_link_libraries` CMake function).

    * The `lift_sim` target should be able to compile and run after this step.


8. The `lib_lift_sim` target should be defined in a separate *CMakeLists.txt* file. 
   
    * Create a new *CMakeLists.txt* file in the *lib_lift_sim* folder.
  
    * **Move** the `lib_lift_sim` library target definition and all the CMake commands related to `lib_lift_sim` from the main *CMakeLists.txt* to this new file.

    * You'll need to fix some paths while doing so.

    * Add the *lib_lift_sim* folder to the main *CMakeLists.txt* file using the `add_subdirectory` function. This will include the *CMakeLists.txt* file from the *lib_lift_sim* folder and make the `lib_lift_sim` library visible to the main *CMakeLists.txt* file.

    * There shouldn't be any leftover mentions of `lib_lift_sim` in the main *CMakeLists.txt* file, except for the `add_subdirectory` function call and the `target_link_libraries` function call.

    * The `lift_sim` target should be able to compile and run after this step.

    
That's all, good luck!