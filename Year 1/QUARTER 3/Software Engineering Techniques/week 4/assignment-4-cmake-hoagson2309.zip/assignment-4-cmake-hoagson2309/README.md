[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/OROJVJsK)
# Lift Simulation project

This program simulates a lift. There are two simulation classes `buttons` and `lift` there are responsible for physical behavior of a lift and a button interface. The functioning of a lift is governed by a *polymorphic state machine*. Every state in it is a class that inherits from `lift_state`. States are switched by swapping pointers.

Head to [ASSIGNMENT.md](ASSIGNMENT.md) for the assignment description.