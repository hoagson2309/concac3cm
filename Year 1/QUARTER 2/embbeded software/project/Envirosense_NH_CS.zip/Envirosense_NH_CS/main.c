/*
* Copyright (c) 2021 Valentin Milea <valentin.milea@gmail.com>
*
* SPDX-License-Identifier: MIT
*/
#include <stdio.h>
#include <stdint.h>
#include "pico/stdlib.h"
#include <assert.h>
#include "hardware/uart.h"
#include "dht.h"

static const dht_model_t DHT_MODEL = DHT22;
static const uint DATA_PIN = 6;

const uint8_t segment_patterns[] = {
    0b00111111, 
    0b00000110, 
    0b01011011, 
    0b01001111, 
    0b01100110, 
    0b01101101, 
    0b01111101, 
    0b00000111, 
    0b01111111,
    0b01101111
};

typedef enum {
    LOW_TEMPERATURE,
    MEDIUM_TEMPERATURE,
    HIGH_TEMPERATURE,
} temperature_state_t;

temperature_state_t state = LOW_TEMPERATURE;

int comfortable_range[2] = {12, 30};

void setup_pin(uint pin) {
    gpio_init(pin);
    gpio_set_dir(pin, GPIO_OUT);
}

void set_RGB_led_color(bool green, bool blue, bool red, const uint green_pin, const uint blue_pin, const uint red_pin) {
    gpio_put(green_pin, green);
    gpio_put(blue_pin, blue);
    gpio_put(red_pin, red);
}

void buzz(uint buzzer_pin, int delay_ms) {
    for (int i = 0; i < 2; i++) {
        gpio_put(buzzer_pin, 1);
        sleep_ms(delay_ms);
        gpio_put(buzzer_pin, 0);
        sleep_ms(delay_ms);
    }
}

void display_on_7segment(uint number, uint segments[]) {
    uint8_t pattern = segment_patterns[number];

    for (int i = 0; i < 7; i++) {
        gpio_put(segments[i], (pattern >> i) & 1);
    }
}

void implement_state(uint green_pin, uint blue_pin, uint red_pin, uint buzzer_pin, uint state) {
    switch (state) {
        case LOW_TEMPERATURE:
            set_RGB_led_color(0, 1, 0, green_pin, blue_pin, red_pin);
            buzz(buzzer_pin, 200);
            break;
        case MEDIUM_TEMPERATURE:
            set_RGB_led_color(1, 0, 0, green_pin, blue_pin, red_pin);
            break;
        case HIGH_TEMPERATURE:
            set_RGB_led_color(0, 0, 1, green_pin, blue_pin, red_pin);
            buzz(buzzer_pin, 500);
            break;
    }
}

void next_state(float temperature, uint green_pin, uint blue_pin, uint red_pin, uint buzzer_pin) {
    switch (state) {
        case LOW_TEMPERATURE:
            if (temperature > comfortable_range[0]) {
                state = MEDIUM_TEMPERATURE;
            }
            break;

        case MEDIUM_TEMPERATURE:
            if (temperature > comfortable_range[1]) {
                state = HIGH_TEMPERATURE;
            } else if (temperature <= comfortable_range[0]) {
                state = LOW_TEMPERATURE;
            }
            break;

        case HIGH_TEMPERATURE:
            if (temperature <= comfortable_range[1]) {
                state = MEDIUM_TEMPERATURE;
            }
            break;
    }
    implement_state(green_pin, blue_pin, red_pin, buzzer_pin, state);
}

int main() {
    stdio_init_all();

    uart_init(uart0, 115200);
    gpio_set_function(0, GPIO_FUNC_UART);
    gpio_set_function(1, GPIO_FUNC_UART);

    const uint GREEN_PIN = 3;
    setup_pin(GREEN_PIN);
    const uint BLUE_PIN = 2;
    setup_pin(BLUE_PIN);
    const uint RED_PIN = 4;
    setup_pin(RED_PIN);
    const uint BUZZER_PIN = 5;
    setup_pin(BUZZER_PIN);

    uint segments_temp_tens[7] = {13, 12, 18, 17, 16, 15, 14};
    uint segments_temp_units[7] = {9, 8, 21, 20, 19, 11, 10};

    for (int i = 0; i < 7; i++) {
        gpio_init(segments_temp_tens[i]);
        gpio_set_dir(segments_temp_tens[i], GPIO_OUT);
        gpio_init(segments_temp_units[i]);
        gpio_set_dir(segments_temp_units[i], GPIO_OUT);
    }

    set_RGB_led_color(1, 0, 0, GREEN_PIN, BLUE_PIN, RED_PIN);

    dht_t dht;
    dht_init(&dht, DHT_MODEL, pio0, DATA_PIN, true /* pull_up */);

        set_RGB_led_color(0, 0, 1, GREEN_PIN, BLUE_PIN, RED_PIN);
        sleep_ms(500);
        set_RGB_led_color(0, 1, 0, GREEN_PIN, BLUE_PIN, RED_PIN);
        sleep_ms(500);
        set_RGB_led_color(1, 0, 0, GREEN_PIN, BLUE_PIN, RED_PIN);
        sleep_ms(500);
        buzz(BUZZER_PIN,200);
        for (uint i = 0; i < 10; i++) {
            display_on_7segment(i, segments_temp_units);
            display_on_7segment((i + 1) % 10, segments_temp_tens);
            sleep_ms(1000);
        } // start up, debugging

        
    while (true) {
        dht_start_measurement(&dht);
        float humidity, temperature_c;
        dht_result_t result = dht_finish_measurement_blocking(&dht, &humidity, &temperature_c);
        if (result == DHT_RESULT_OK) {
            printf("%d C, %d%% humidity\n", (int)temperature_c, (int)humidity);
        } else if (result == DHT_RESULT_TIMEOUT) {
            puts("DHT sensor not responding. Please check your wiring.");
        } else {
            assert(result == DHT_RESULT_BAD_CHECKSUM);
            puts("Bad checksum");
        }

        uint8_t t_units_digit = (uint8_t)(temperature_c) % 10;
        display_on_7segment(t_units_digit, segments_temp_units);

        sleep_ms(50);

        uint8_t t_tens_digit = ((uint8_t)(temperature_c) / 10) % 10;
        display_on_7segment(t_tens_digit, segments_temp_tens);

        sleep_ms(50);

        char buffer[16];
        sprintf(buffer, "%d\n", (int) humidity);
        uart_puts(uart0, buffer);
        sleep_ms(50);

        next_state(temperature_c, GREEN_PIN, BLUE_PIN, RED_PIN, BUZZER_PIN);
        sleep_ms(500);
    }
    return 0;
}
